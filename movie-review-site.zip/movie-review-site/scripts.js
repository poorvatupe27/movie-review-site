document.addEventListener('DOMContentLoaded', () => {
    const movieCategory = document.getElementById('movie-category');
    const movieTitle = document.getElementById('movie-title');
    const moviePoster = document.getElementById('movie-poster');
    const movieTitleDisplay = document.getElementById('movie-title-display');
    const releaseDate = document.getElementById('release-date');
    const director = document.getElementById('director');
    const description = document.getElementById('description');
    const reviewForm = document.getElementById('review-form');
    const reviewList = document.getElementById('review-list');

    let movies = [];

    const fetchMovies = async () => {
        try {
            const response = await fetch('http://localhost:3000/movies');
            if (!response.ok) throw new Error('Network response was not ok');
            movies = await response.json();
            populateMovies(movies);
        } catch (error) {
            console.error('Error fetching movies:', error);
            alert('Failed to load movies. Please try again later.');
        }
    };

    const populateMovies = (movies) => {
        movieTitle.innerHTML = '';
        movies.forEach(movie => {
            const option = document.createElement('option');
            option.value = movie.id;
            option.textContent = movie.title;
            movieTitle.appendChild(option);
        });
        movieTitle.value = movies[0].id;
        updateMovieDetails(movies[0]);
    };

    const updateMovieDetails = (movie) => {
        moviePoster.src = `http://localhost:3000${movie.poster}`;
        moviePoster.onerror = () => {
            moviePoster.src = 'mby.jpg'; // Use a placeholder or fallback image
        };
        movieTitleDisplay.textContent = movie.title;
        releaseDate.textContent = movie.release_date;
        director.textContent = movie.director;
        description.textContent = movie.description;
    };

    movieTitle.addEventListener('change', (e) => {
        const selectedMovie = movies.find(movie => movie.id == movieTitle.value);
        updateMovieDetails(selectedMovie);
    });

    reviewForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const reviewText = document.getElementById('review-text').value;
        const movieId = movieTitle.value;

        if (reviewText) {
            try {
                const response = await fetch('http://localhost:3000/reviews', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ movieId, review: reviewText })
                });

                if (!response.ok) throw new Error('Failed to submit review');
                const result = await response.json();
                const li = document.createElement('li');
                li.textContent = result.review;
                reviewList.appendChild(li);
                reviewForm.reset();
            } catch (error) {
                console.error('Error submitting review:', error);
                alert('Failed to submit review. Please try again later.');
            }
        }
    });

    fetchMovies();
});
