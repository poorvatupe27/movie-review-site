const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

// CORS setup
app.use(cors({
    origin: 'http://127.0.0.1:5500', // Frontend URL
    methods: ['GET', 'POST'],
}));

// Middleware
app.use(express.json());
app.use(express.static('public')); // Serve static files from the public directory

let movies = [
    { id: 1, title: "Taare Zameen Par", release_date: "21 December 2007", director: "Aamir Khan", description: "Ishaan is criticised by his parents for his poor academic performance and is sent away to a boarding school. Ram, an art teacher, however, realises he has dyslexia and helps him uncover his potential.", poster: "/tzp.jpeg" },
    { id: 2, title: "Student Of The Year", release_date: "19 October 2012", director: "Karan Johar", description: "Several alumni reminisce about their final year at St. Theresa's College and the events that shaped their lives.", poster: "/soty.jpg" },
    { id: 3, title: "Main Tera Hero", release_date: "4 April 2014", director: "David Dhawan", description: "A young man’s quest to win over a beautiful girl turns into a chaotic journey when he faces a rival gangster and other comedic situations.", poster: "/mth.jpg" },
    { id: 4, title: "Zindagi Na Milegi Dobara", release_date: "15 July 2011", director: "Zoya Akhtar", description: "Three friends set out on a road trip in Spain, where they confront their fears and rediscover their bond.", poster: "/znmd.jpg" },
    { id: 5, title: "Yeh Jawaani Hai Deewani", release_date: "31 May 2013", director: "Ayan Mukerji", description: "A group of friends reconnects years after their college days, discovering their dreams and relationships have changed.", poster: "/yjhd.jpg" },
    { id: 6, title: "Dil Dhadakne Do", release_date: "5 June 2015", director: "Zoya Akhtar", description: "A wealthy family’s journey on a cruise reveals hidden truths and personal conflicts among its members.", poster: "/ddd.jpg" },
    { id: 7, title: "All the Bright Places", release_date: "28 February 2020", director: "Brett Haley", description: "Two teens struggle with the emotional and physical scars of their past and discover that even the smallest places and moments can mean something.", poster: "/abp.jpg" },
    { id: 8, title: "Me Before You", release_date: "3 June 2016", director: "Thea Sharrock", description: "A young woman forms an unlikely bond with a recently-paralyzed man she's taking care of.", poster: "/mby.jpg" },
    { id: 9, title: "Midnight Sun", release_date: "23 March 2018", director: "Scott Speer", description: "A teenage girl with a rare condition that makes her sensitive to sunlight falls in love with a boy who brings light into her life.", poster: "/ms.jpg" },
    { id: 10, title: "Purple Hearts", release_date: "29 July 2022", director: "Elizabeth Allen Rosenbaum", description: "A musician and a soldier enter a fake marriage for benefits, only to find that their feelings become more real.", poster: "/ph.jpg" },
    { id: 11, title: "The Notebook", release_date: "25 June 2004", director: "Nick Cassavetes", description: "A young couple falls deeply in love during the early years of World War II, with their relationship tested by war and time.", poster: "/tn.jpg" },
    { id: 12, title: "Mean Girls", release_date: "30 April 2004", director: "Mark Waters", description: "A high school girl navigates the complicated social dynamics of teenage life after moving from Africa to America.", poster: "/mg.jpg" },
];

let reviews = []; // Array to store reviews

// Routes
app.get('/', (req, res) => {
    res.send('Welcome to the Movie Review API!');
});

app.get('/movies', (req, res) => {
    console.log('GET /movies requested');
    res.json(movies);
});

app.get('/reviews', (req, res) => {
    console.log('GET /reviews requested');
    res.json(reviews);
});

app.post('/reviews', (req, res) => {
    const { movieId, review } = req.body;
    reviews.push({ movieId, review });
    res.json({ movieId, review });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
